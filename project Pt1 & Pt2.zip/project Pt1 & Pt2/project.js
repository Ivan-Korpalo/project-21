

function enterName(){
    //saves player name into a variable
  document.getElementById('id01').style.display='block'
  var name = document.getElementById("myName").value;

  // prints the player name
  var text1 = document.getElementById("name");
  text1.innerHTML = "Welcome, "+name;

//sets timer of 3 seconds before switching screens
  setTimeout(function(){  document.getElementById('id01').style.display='none';  }, 3000);


}













    



